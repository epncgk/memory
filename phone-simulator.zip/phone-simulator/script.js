/* 휴대전화 시뮬레이터 동작 */

const $ = s => document.querySelector(s), scr = $('#scr');
/* ===== 문자 답장 설정: [정규식, 답장] 을 자유롭게 수정/추가하세요 ===== */
const REPLIES = [[/안녕|hi|hello/i, '안녕, Astina. 이제야 답하네.'], [/어디|where/i, '비밀. 곧 직접 확인하게 될 거야.'], [/보고\s?싶|miss/i, '…나도. 그 말은 직접 듣고 싶어.'], [/사랑|love/i, '그런 말은 함부로 하는 거 아니야, Astina.'], [/미안|sorry/i, '사과는 됐어. 대신 오늘 저녁에 와.'], [/언제|몇\s?시|when/i, '오늘 밤 9시. 늦지 마.'], [/누구|who/i, 'Terriod. 벌써 잊었어?'], [/전화|call/i, '지금은 통화 못 해. 문자로 해.']];
const DEFAULT = ['그래, 알았어.', '계속 말해 봐.', '읽고 있어, Astina.', '음… 그건 만나서 얘기하자.'];
const now = () => new Date(), hm = d => d.toLocaleTimeString('ko-KR', { hour: 'numeric', minute: '2-digit' });
const msgs = [{ m: 0, x: '내일 일정 확인했어?', d: new Date(Date.now() - 864e5), r: 1 }, { m: 1, x: '응, 확인했어. 걱정 마', d: new Date(Date.now() - 864e5 + 6e4), r: 1 },
    { m: 0, x: 'Astina, 어디야? 아까부터 계속 연락했는데.', d: new Date(Date.now() - 6e4), r: 0 }];
let locked = true, cur = null, welcomed = false;
function tick() {
    const d = now();
    const t = d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: false });
    $('#clk').textContent = t;
    $('#lt').textContent = t;
    const ds = d.toLocaleDateString('ko-KR', { month: 'long', day: 'numeric', weekday: 'long' });
    $('#ld').textContent = ds;
    $('#ch').textContent = d.getHours() % 12 || 12;
    $('#cm').textContent = String(d.getMinutes()).padStart(2, '0');
    $('#cd').innerHTML = d.toLocaleDateString('en-US', { weekday: 'short' }) + '<br>' + d.getDate();
    $('#tc').textContent = t;
    $('#td').textContent = ds;
}
setInterval(tick, 1000);
tick();
const BASE_W = 393, BASE_H = 852;
function fit() {
    const vv = window.visualViewport, de = document.documentElement;
    const W = Math.round(Math.min(vv ? vv.width : Infinity, innerWidth, de.clientWidth || Infinity));
    const H = Math.round(Math.min(vv ? vv.height : Infinity, innerHeight, de.clientHeight || Infinity));
    const full = W < 700;
    const scale = full ? W / BASE_W : Math.min((H - 32) / BASE_H, W / BASE_W);
    const height = full ? H / scale : BASE_H;
    document.body.classList.toggle('full', full);
    de.style.setProperty('--h', height + 'px');
    $('#phone').style.transform = `translate(-50%,-50%) scale(${scale})`;
}
addEventListener('resize', fit);
addEventListener('orientationchange', () => setTimeout(fit, 200));
if (window.visualViewport)
    visualViewport.addEventListener('resize', fit);
fit();
/* 홈 */
const SV = p => `<svg viewBox="0 0 24 24" width="34" height="34" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">${p}</svg>`;
const D = { m: '<path d="M5 5h14a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1h-9l-5 4v-4a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1z"/>', p: '<path d="M6.5 4l2.5 4-1.8 1.5a10 10 0 0 0 4.8 4.8L14 12.5l4 2.5-1 3.5c-8 1-13-5-12-11z"/>', g: '<text x="12" y="18" text-anchor="middle" font-size="20" font-weight="700" font-family="Georgia,serif" fill="currentColor" stroke="none">G</text>', f: '<rect x="3" y="5" width="18" height="14" rx="3"/><circle cx="9" cy="10" r="1.5"/><path d="M4 18l5-5 4 4 3-3 4 4"/>', u: '<path d="M9 18V6l10-2v12"/><circle cx="7" cy="18" r="2"/><circle cx="17" cy="16" r="2"/>', c: '<rect x="3" y="7" width="18" height="13" rx="3"/><circle cx="12" cy="13.5" r="3.5"/><path d="M8 7l1.5-3h5L16 7"/>', n: '<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M9 8h6M9 12h6M9 16h3"/>', k: '<rect x="4" y="5" width="16" height="15" rx="3"/><path d="M4 10h16M8 3v4M16 3v4"/>', t: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>', v: '<path d="M5 4h10a3 3 0 0 1 3 3v13H8a3 3 0 0 1-3-3z"/><path d="M5 17a3 3 0 0 1 3-3h10"/>', w: '<rect x="5" y="3" width="14" height="8" rx="2"/><rect x="5" y="13" width="14" height="8" rx="2"/>', a: '<path d="M4 12v0M8 8v8M12 5v14M16 9v6M20 12v0"/>' };
const A = { m: ['Messages', '#a9bdaa', '#fff'], p: ['Phone', '#a0b5c8', '#fff'], g: ['Google', '#f4f2ee', '#4a4f57'], f: ['Images', '#dccbc6', '#fff'], u: ['Music', '#bba9b9', '#fff'], c: ['Camera', '#8e98a5', '#fff'], n: ['Note', '#ebe4d3', '#6b6558'], k: ['Calendar', '#f4f2ee', '#c46f7e'], t: ['Clock', '#6e7683', '#fff'], v: ['Novel', '#b8a58c', '#fff'], w: ['Webtoon', '#8fb0a0', '#fff'], a: ['Audio', '#9aa3c4', '#fff'] };
const ic = id => `<div class="ic" data-a="${id}"><i style="background:${A[id][1]};color:${A[id][2]}">${SV(D[id])}</i><span>${A[id][0]}</span></div>`;
function cal() {
    const d = now(), y = d.getFullYear(), m = d.getMonth(), f = new Date(y, m, 1).getDay(), n = new Date(y, m + 1, 0).getDate();
    $('#kh').textContent = `${y}년 ${m + 1}월`;
    let h = '일월화수목금토'.split('').map(x => `<b>${x}</b>`).join('') + '<span></span>'.repeat(f);
    for (let i = 1; i <= n; i++)
        h += `<span class="${i == d.getDate() ? 'td' : ''}">${i}</span>`;
    $('#kg').innerHTML = h;
}
const set = (s, l) => $(s).innerHTML = l.split('').map(ic).join('');
set('#tr', 'tknu');
set('#bl', 'gvwa');
set('#dock', 'pmfc');
document.addEventListener('click', e => {
    const i = e.target.closest('.ic');
    if (!i || locked)
        return;
    const a = i.dataset.a;
    if (a == 'h') {
        openApp('m');
        openThread();
    }
    else if (a == 'c')
        $('#cam').click();
    else
        openApp(a);
});
function openApp(id) {
    cur = id;
    document.querySelectorAll('.app').forEach(a => a.classList.toggle('open', a.id == 'a-' + id));
    scr.classList.toggle('lt', 'gnkva'.includes(id));
    if (id == 'k')
        cal();
    if (id == 'v')
        nvList();
    if (id == 'w')
        wtList();
    $('#banner').classList.remove('s');
    if (id == 'm')
        showList();
}
function goHome() {
    cur = null;
    document.querySelectorAll('.app').forEach(a => a.classList.remove('open'));
    scr.classList.toggle('lt', !locked);
    $('#th').classList.remove('o');
}
function unlock() {
    locked = false;
    scr.classList.add('lt');
    $('#lock').classList.add('gone');
    if (!welcomed) {
        welcomed = true;
        setTimeout(() => receive('방금 말한 거 잊지 마. 지금 나와, 할 말이 있어. — T'), 2500);
    }
}
$('#hb').onclick = () => locked ? unlock() : goHome();
let y0 = null;
$('#lock').onpointerdown = e => y0 = e.clientY;
$('#lock').onpointerup = e => {
    if (y0 != null && y0 - e.clientY > 70)
        unlock();
    y0 = null;
};
/* 알림 */
function notes() {
    $('#nots').innerHTML = msgs.filter(m => !m.m && !m.r).map(m => `<div class="n"><small><span>💬 메시지</span><span>${(now() - m.d) < 12e4 ? '지금' : hm(m.d)}</span></small><b>Terriod</b>${m.x}</div>`).join('');
    document.querySelectorAll('.n').forEach(n => n.onclick = () => {
        unlock();
        openApp('m');
        openThread();
    });
}
function receive(x) {
    msgs.push({ m: 0, x, d: now(), r: 0 });
    if (navigator.vibrate)
        navigator.vibrate(200);
    if (cur == 'm' && $('#th').classList.contains('o'))
        return openThread();
    if (locked)
        notes();
    else {
        const b = $('#banner');
        b.innerHTML = `<div class="n"><small><span>💬 메시지</span><span>지금</span></small><b>Terriod</b>${x}</div>`;
        b.classList.add('s');
        b.onclick = () => {
            openApp('m');
            openThread();
        };
        setTimeout(() => b.classList.remove('s'), 4500);
    }
    if (cur == 'm')
        showList();
}
/* 메시지 */
function showList() {
    $('#th').classList.remove('o');
    const l = msgs[msgs.length - 1], u = msgs.some(m => !m.m && !m.r);
    $('#ml').innerHTML = `<div class="row" id="r1"><div class="av">T</div><div><b>Terriod</b><div style="color:#999;font-size:14px">${l.x}</div></div>${u ? '<div class="dot"></div>' : ''}</div>`;
    $('#r1').onclick = openThread;
}
function openThread() {
    msgs.forEach(m => m.r = 1);
    $('#th').classList.add('o');
    draw();
    notes();
}
function draw() {
    let h = '<div class="ts">오늘 ' + hm(now()) + '</div>';
    msgs.forEach(m => h += `<div class="b ${m.m ? 'me' : 't'}">${m.x.replace(/</g, '&lt;')}</div>`);
    $('#bub').innerHTML = h;
    $('#bub').scrollTop = 1e5;
}
$('#bk').onclick = showList;
function send() {
    const v = $('#mi').value.trim();
    if (!v)
        return;
    $('#mi').value = '';
    msgs.push({ m: 1, x: v, d: now(), r: 1 });
    draw();
    const r = (REPLIES.find(a => a[0].test(v)) || [0, DEFAULT[Math.random() * DEFAULT.length | 0]])[1];
    setTimeout(() => {
        $('#bub').insertAdjacentHTML('beforeend', '<div class="b t" id="ty">···</div>');
        $('#bub').scrollTop = 1e5;
    }, 600);
    setTimeout(() => {
        const t = $('#ty');
        t && t.remove();
        msgs.push({ m: 0, x: r, d: now(), r: 1 });
        draw();
    }, 1800 + Math.random() * 1000);
}
$('#sd').onclick = send;
$('#mi').onkeydown = e => {
    if (e.key == 'Enter')
        send();
};
/* 전화 */
let num = '', ct;
$('#keys').innerHTML = '123456789*0#'.split('').map(k => `<button>${k}</button>`).join('') + '<span></span><button class="call" id="cb">📞</button>';
$('#keys').onclick = e => {
    const b = e.target.closest('button');
    if (!b)
        return;
    if (b.id == 'cb')
        return call(num);
    num += b.textContent;
    $('#num').textContent = num;
};
$('#del').onclick = () => {
    num = num.slice(0, -1);
    $('#num').textContent = num;
};
$('#fav').onclick = () => call('Terriod');
function call(n) {
    if (!n)
        return;
    $('#cn').textContent = n;
    $('#cs').textContent = '연결 중…';
    $('#calling').classList.add('o');
    let s = 0;
    clearInterval(ct);
    setTimeout(() => {
        ct = setInterval(() => {
            s++;
            $('#cs').textContent = String(s / 60 | 0).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0');
        }, 1000);
        $('#cs').textContent = '00:00';
    }, 2000);
}
$('#end').onclick = () => {
    clearInterval(ct);
    $('#calling').classList.remove('o');
};
/* Google */
$('#gq').onkeydown = e => {
    if (e.key != 'Enter' || !e.target.value.trim())
        return;
    const q = e.target.value.trim(), a = document.createElement('a');
    a.href = 'https://www.google.com/search?q=' + encodeURIComponent(q);
    a.target = '_blank';
    a.textContent = 'Google에서 검색 결과 보기 →';
    const g = $('#gr');
    g.innerHTML = '<p>검색어: <b></b></p>';
    g.querySelector('b').textContent = q;
    g.append(a);
};
/* 사진 */
const WP = 'assets/wallpaper.jpg';
let ph = [WP, 'linear-gradient(#f6d365,#fda085)', 'linear-gradient(#a1c4fd,#c2e9fb)', 'linear-gradient(#84fab0,#8fd3f4)', 'linear-gradient(#d4fc79,#96e6a1)', 'linear-gradient(#fbc2eb,#a6c1ee)'];
function drawP() {
    $('#pg').innerHTML = ph.map((p, i) => `<div data-i="${i}" style="background-image:${p.startsWith('linear') ? p : `url(${p})`}"></div>`).join('');
}
drawP();
$('#pg').onclick = e => {
    const d = e.target.closest('div');
    if (!d)
        return;
    const p = ph[d.dataset.i];
    $('#pv').style.display = 'block';
    $('#pv').style.backgroundImage = p.startsWith('linear') ? p : `url(${p})`;
};
$('#pv').onclick = () => $('#pv').style.display = 'none';
$('#up').onchange = e => {
    const f = e.target.files[0];
    if (f) {
        ph.unshift(URL.createObjectURL(f));
        drawP();
    }
};
/* 음악 */
const T = [{ t: 'Midnight Rain', a: 'Terriod', n: [0, 3, 7, 10] }, { t: 'Velvet Hour', a: 'Astina', n: [2, 5, 9, 12] }, { t: 'Blue Static', a: 'Terriod', n: [0, 5, 8, 12] }];
let ti = 0, pl = false, pos = 0, ac, iv, au = new Audio();
function ui() {
    $('#tt').textContent = T[ti].t;
    $('#ta').textContent = T[ti].a;
    $('#pp').textContent = pl ? '⏸️' : '▶️';
    $('#tl').innerHTML = T.map((t, i) => `<div class="tr ${i == ti ? 'a' : ''}" data-i="${i}"><span>${t.t}</span><span>${t.a}</span></div>`).join('');
}
function stop() {
    clearInterval(iv);
    au.pause();
}
function play() {
    stop();
    pl = true;
    ui();
    const t = T[ti];
    if (t.src) {
        au.src = t.src;
        au.play();
        iv = setInterval(() => $('#pr i').style.width = (au.currentTime / au.duration * 100 || 0) + '%', 300);
        return;
    }
    ac = ac || new (window.AudioContext || window.webkitAudioContext)();
    let k = 0;
    iv = setInterval(() => {
        pos = (pos + .4 / 180 * 100);
        $('#pr i').style.width = pos % 100 + '%';
        const o = ac.createOscillator(), g = ac.createGain();
        o.frequency.value = 220 * 2 ** (t.n[k++ % 4] / 12);
        g.gain.setValueAtTime(.15, ac.currentTime);
        g.gain.exponentialRampToValueAtTime(.001, ac.currentTime + .38);
        o.connect(g).connect(ac.destination);
        o.start();
        o.stop(ac.currentTime + .4);
    }, 400);
}
$('#pp').onclick = () => {
    if (pl) {
        pl = false;
        stop();
        ui();
    }
    else
        play();
};
const go = d => {
    ti = (ti + d + T.length) % T.length;
    pos = 0;
    $('#pr i').style.width = 0;
    play();
};
$('#nx').onclick = () => go(1);
$('#pv2').onclick = () => go(-1);
$('#tl').onclick = e => {
    const r = e.target.closest('.tr');
    if (r) {
        ti = +r.dataset.i;
        pos = 0;
        play();
    }
};
$('#au').onchange = e => {
    const f = e.target.files[0];
    if (f) {
        T.push({ t: f.name.replace(/\.\w+$/, ''), a: '내 음악', src: URL.createObjectURL(f) });
        ti = T.length - 1;
        play();
    }
};
ui();
notes();
document.documentElement.style.setProperty('--wp', `url(${WP})`);
$('#cam').onchange = $('#up').onchange;
const NV = [['달빛 아래의 편지', 'Astina van Atalenta', '편지는 비에 젖어 있었다. 잉크가 번졌는데도 마지막 줄만은 선명했다. 내일 밤, 시계탑 아래에서. 아스티나는 창밖을 보았다. 구름 사이로 달이 얇게 걸려 있었다.\n\n그녀는 한참을 망설이다 외투를 집어 들었다. 누가 보냈는지 알 수 없었지만, 이상하게도 두렵지 않았다. 오래전에 잃어버린 무언가가 그 문장 안에 있는 것 같았다.'], ['여름의 끝에서', 'Terriod', '마지막 매미 소리가 그친 날, 우리는 방파제에 앉아 있었다. 바다는 늦은 오후의 빛을 천천히 삼키고 있었다.\n\n너는 아무 말도 하지 않았고, 나도 묻지 않았다. 어떤 대답은 묻지 않아야 오래 남는다는 걸, 그때는 이미 알고 있었다.'], ['유리 정원', 'Anonymous', '유리로 된 정원에는 시간이 천천히 흘렀다. 꽃잎은 지지 않았고, 햇빛은 늘 같은 각도로 들어왔다.\n\n문을 연 사람만이 그 이유를 알게 된다고 했다. 그리고 한 번 알게 되면, 다시는 밖으로 나갈 수 없다고도.']];
let fs = 17;
function nvList() {
    $('#vh').textContent = 'Novel';
    $('#vb').innerHTML = NV.map((b, i) => `<div class="bk" data-i="${i}"><b>${b[0]}</b><div>${b[1]}</div></div>`).join('');
}
$('#vb').onclick = e => {
    const k = e.target.closest('.bk'), id = e.target.id;
    if (k) {
        const b = NV[k.dataset.i];
        $('#vh').textContent = b[0];
        $('#vb').innerHTML = `<div style="display:flex;gap:10px;margin-bottom:10px"><span class="pb" style="margin:0" id="vback">‹ 목록</span><span class="pb" style="margin:0" id="vm">A−</span><span class="pb" style="margin:0" id="vp">A+</span></div><div id="vr" style="font-size:${fs}px">${b[2].replace(/\n/g, '<br>')}</div>`;
    }
    else if (id == 'vback')
        nvList();
    else if (id == 'vp' || id == 'vm') {
        fs += id == 'vp' ? 1 : -1;
        $('#vr').style.fontSize = fs + 'px';
    }
};
const WT = [['Moonlit Days', '#7b8fb8', '#c9b8d9'], ['Blue Hour', '#6fa3a0', '#b5d6c7'], ['Paper Hearts', '#c48a96', '#f0c9c0']];
function wtList() {
    $('#wh').textContent = 'Webtoon';
    $('#wb').innerHTML = WT.map((w, i) => `<div class="wtr" data-i="${i}"><div class="wtc" style="background:linear-gradient(135deg,${w[1]},${w[2]})"></div><div><b>${w[0]}</b><div style="color:#999;font-size:13px">1화 · 무료</div></div></div>`).join('') + '<label class="pb" style="display:inline-block;margin:14px 0">＋ 이미지로 에피소드 추가<input type="file" id="wup" accept="image/*" multiple hidden></label>';
}
function wtRead(h, b) {
    $('#wh').textContent = h;
    $('#wb').innerHTML = '<span class="pb" id="wback" style="margin:0 0 10px;display:inline-block">‹ 목록</span>' + b;
}
$('#wb').onclick = e => {
    const r = e.target.closest('.wtr');
    if (r) {
        const w = WT[r.dataset.i], c = ['비가 그친 새벽.', '냯선 편지가 도착했다.', '그녀는 천천히 문을 열었다.', '…누구세요?', '그리고 이야기는 시작된다.'];
        wtRead(w[0] + ' 1화', c.map((t, n) => `<div class="pn" style="background:linear-gradient(${n * 50 + 20}deg,${w[1]},${w[2]})">컷 ${n + 1}<br>${t}</div>`).join(''));
    }
    else if (e.target.id == 'wback')
        wtList();
};
$('#wb').onchange = e => {
    if (e.target.id == 'wup') {
        const f = [...e.target.files];
        if (f.length)
            wtRead('내 에피소드', f.map(x => `<img src="${URL.createObjectURL(x)}" style="width:100%;display:block">`).join(''));
    }
};
$('#pwid').onclick = () => openApp('f');
const AE = [["그녀와 야수 OST - 해피엔드 (네번째 ED)", "2023.09.07", "3:40", "0"], ["그녀와 야수 네번째 FREE TALK", "2023.07.22", "49:49", "17"], ["그녀와 야수 네번째 NG", "2023.07.22", "6:44", "2"], ["그녀와 야수 88화 完", "2023.07.22", "23:02", "16"], ["그녀와 야수 87화", "2023.07.20", "18:55", "13"], ["그녀와 야수 86화", "2023.07.18", "28:53", "20"], ["그녀와 야수 85화", "2023.07.15", "21:17", "14"], ["그녀와 야수 84화", "2023.07.13", "24:14", "16"], ["그녀와 야수 83화", "2023.07.11", "25:29", "17"], ["그녀와 야수 82화", "2023.07.08", "32:02", "22"], ["그녀와 야수 81화", "2023.07.06", "30:01", "21"], ["그녀와 야수 80화", "2023.07.04", "23:24", "16"], ["그녀와 야수 79화", "2023.07.01", "28:55", "20"], ["그녀와 야수 78화", "2023.06.29", "15:47", "11"], ["그녀와 야수 77화", "2023.06.27", "20:27", "14"], ["그녀와 야수 76화", "2023.06.24", "26:38", "18"], ["그녀와 야수 75화", "2023.06.22", "22:13", "15"], ["그녀와 야수 74화", "2023.06.20", "22:23", "15"], ["그녀와 야수 73화", "2023.06.17", "19:53", "13"], ["그녀와 야수 72화", "2023.06.15", "17:36", "12"]];
let ei = 19;
const sv = (p, z = 18, f = 'none') => `<svg viewBox="0 0 24 24" width="${z}" height="${z}" fill="${f}" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">${p}</svg>`;
const PL = '<svg width="28" height="28" viewBox="0 0 24 24" fill="#111"><path d="M6 4l14 8-14 8z"/></svg>', PA = '<svg width="28" height="28" viewBox="0 0 24 24" fill="#111"><path d="M6 4h4v16H6zM14 4h4v16h-4z"/></svg>';
$('#a-a').innerHTML = `<div class="ah"><span id="ab-b">${sv('<path d="M15 5l-7 7 7 7"/>', 26)}</span><b>그녀와 야수</b><span style="margin-left:auto">${sv('<path d="M12 15V4M8 8l4-4 4 4M5 12v8h14v-8"/>', 24)}</span><span style="color:#ff2d55;margin-left:6px">${sv('<path d="M12 20s-7-4.5-7-10a4 4 0 0 1 7-2.5A4 4 0 0 1 19 10c0 5.5-7 10-7 10z"/>', 28, 'currentColor')}</span></div>
<div id="abx"><div class="cvr"></div><div class="ai2"><h2>그녀와 야수</h2><div class="il"><span>원작 : 마지노선</span><span>총 101화 (재생시간 33 시간 26 분)</span><span>완결</span></div><div>등급 : <span style="color:#1a56e8">전체 이용 가능</span></div><div>제작사 : 오디오코믹스</div>
<div class="va">${sv('<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>', 22)}<span>이슬, 강성우, 선우현수, 백승철, 김민주, 박성영, 김두리, 이다슬, 김보나, 채안석</span></div>
<div class="chs"><span id="m-info">${sv('<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.5"/>', 16)} 작품정보 ›</span><span>${sv(D.f, 16)} 현장사진 ›</span><span>${sv('<path d="M4 20l4-1 11-11-3-3L5 16z"/>', 16)} 소감 ›</span><span>${sv(D.m, 16)} 댓글 ›</span></div>
<div id="ai" style="display:none"><h4>줄거리</h4><p>전설적인 시조 마티나가 백 년 뒤 귀족 가문의 딸 아스티나로 환생한다. 아버지의 파산으로 야수의 모습을 한 테리오드 대공에게 팔려 가지만, 그녀는 검술로 그를 제압해 길들이기 시작하고, 어느 밤 그가 사람으로 변하면서 이야기가 크게 달라진다.</p><h4>배역</h4><p>이슬 (아스티나 레테)<br>강성우 (테리오드 반 아탈렌타)<br>선우현수 (히센)<br>백승철 (올리버)<br>김민주 (벤자민)<br>박성영 (아서)<br>김두리 (제시)<br>이다슬 (이시스)<br>김보나 (앤서린)<br>채안석 (프리모)</p></div>
<div class="tg"><i>#첫사랑</i><i>#프로성우</i><i>#로맨스판타지</i><i>#서양풍</i><i>#정략결혼</i><i>#선결혼후연애</i><i>#로판</i><i>#전생환생</i><i>#애절물</i></div>
<div class="mk" id="mk"><span class="yt">▶</span> 그녀와 야수 네번째 메이킹 필름 <em>⌄</em></div><div id="mkl" style="display:none;color:#555;line-height:2">그녀와 야수 세번째 메이킹 필름<br>그녀와 야수 두번째 메이킹 필름<br>그녀와 야수 첫번째 메이킹 필름</div>
<div class="nt">ⓘ 뽑기권 제외 회차 안내</div></div><div id="ae"></div></div>
<div id="mini"><div class="mpr"><i id="mbar2" style="width:38%"></i></div><div class="mth cvr"></div><div class="mtx"><b id="mt2"></b><small>마지노선</small></div><span id="m-pv"><svg width="26" height="26" viewBox="0 0 24 24" fill="#111"><path d="M6 5h3v14H6zM20 5v14L10 12z"/></svg></span><span id="m-pp"></span><span id="m-nx"><svg width="26" height="26" viewBox="0 0 24 24" fill="#111"><path d="M15 5h3v14h-3zM4 5v14l10-7z"/></svg></span><span>${sv('<path d="M4 6h14M4 12h14M4 18h8M17 15l4 3-4 3z"/>', 26)}</span></div>
<div id="nav"><div id="nav-home">${sv('<path d="M4 11l8-7 8 7v9H4z"/>', 26)}홈</div><div>${sv('<rect x="4" y="9" width="16" height="11" rx="2"/><path d="M7 5h10"/>', 26)}보관함</div><div class="on">${sv('<circle cx="11" cy="11" r="6"/><path d="M16 16l4 4"/>', 26)}검색</div><div>${sv('<path d="M6 17v-6a6 6 0 0 1 12 0v6l1.5 2h-15zM10 21h4"/>', 26)}알림</div><div>${sv('<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>', 26)}MY</div></div>`;
$('#ae').innerHTML = AE.map((e, i) => `<div class="aep${i == ei ? ' on' : ''}" data-i="${i}" style="padding:12px 18px"><div class="ath"></div><div class="atx"><b>${e[0]}</b><small>${e[1]} · 재생시간 ${e[2]}</small></div><span class="aco">${e[3]}코인</span></div>`).join('');
$('#mt2').textContent = AE[ei][0];
$('#m-pp').innerHTML = PL;
function setEp(i) {
    ei = i;
    const n = AE[i][0];
    let k = T.findIndex(t => t.t == n);
    if (k < 0) {
        T.push({ t: n, a: '마지노선', n: [0, 4, 7, 11] });
        k = T.length - 1;
    }
    ti = k;
    $('#mt2').textContent = n;
    document.querySelectorAll('.aep').forEach((x, j) => x.classList.toggle('on', j == i));
}
$('#ae').onclick = e => {
    const r = e.target.closest('.aep');
    if (r) {
        pos = 0;
        setEp(+r.dataset.i);
        play();
    }
};
$('#m-pp').onclick = () => {
    if (pl) {
        pl = false;
        stop();
        ui();
    }
    else {
        setEp(ei);
        play();
    }
};
$('#m-pv').onclick = () => {
    pos = 0;
    setEp((ei + AE.length - 1) % AE.length);
    play();
};
$('#m-nx').onclick = () => {
    pos = 0;
    setEp((ei + 1) % AE.length);
    play();
};
$('#m-info').onclick = () => {
    const v = $('#ai');
    v.style.display = v.style.display == 'block' ? 'none' : 'block';
};
$('#mk').onclick = () => {
    const v = $('#mkl');
    v.style.display = v.style.display == 'block' ? 'none' : 'block';
};
$('#nav-home').onclick = goHome;
$('#ab-b').onclick = goHome;
setInterval(() => {
    $('#m-pp').innerHTML = pl ? PA : PL;
    if (pl)
        $('#mbar2').style.width = (parseFloat($('#pr i').style.width) || 0) + '%';
}, 300);
